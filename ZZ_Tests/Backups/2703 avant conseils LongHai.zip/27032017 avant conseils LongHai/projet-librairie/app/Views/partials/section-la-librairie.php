<section class="container-fluid">
        <section class="container">
            <div class="row">   
                <div col-xd-4 col-lg-4>
                    <h3>Ceci est la future page "La librairie"</h3>
                </div>

                <ul>
                	<li><a href="#!">Livres</a></li>
                	<li><a href="#!">Papeterie</a></li>
                	<li><a href="#!">Loisirs et Jeux</a></li>
                </ul>

            </div>
        </section>
</section>  <!-- section container-fluid-->