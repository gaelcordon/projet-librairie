### Répertoire app/Model

Ce répertoire contient vos différents modèles de données. Vous pouvez y créer des sous-dossiers sans problème, du moment que les espaces de noms de vos modèles collent à la structure de ces dossiers. 

Tous vos modèles devraient hériter de \W\Model\Model, le modèle de données de base du framework W. Votre UserModel pourrait toutefois plutôt hériter de \W\Model\UserModel, afin de bénéficier de quelques méthodes supplémentaires. 