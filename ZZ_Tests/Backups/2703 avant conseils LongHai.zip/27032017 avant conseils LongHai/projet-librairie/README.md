## W

W est un framework minimaliste. Il suit les structures et les grand thèmes des frameworks PHP OO MVC actuels, tout en en facilitant l'approche. 

---

####Pour télécharger le framework et en consulter la documentation :

1. Dans un terminal : 

  ```
  cd c:/xampp/htdocs
  composer create-project webforce3/w nom_de_mon_projet
  ```

2. Naviguez vers http://localhost/nom_de_mon_projet/docs/tuto/


####Auteurs :
* Guillaume Sylvestre : [@gsylvestre](https://github.com/gsylvestre) (auteur original)
* Axel Wargnier : [@axessweb](https://github.com/axessweb)