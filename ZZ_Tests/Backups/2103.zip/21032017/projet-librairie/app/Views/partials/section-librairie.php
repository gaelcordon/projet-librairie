<section class="container-fluid">
        <section class="container">
            <div class="row">   
                <div col-xd-4 col-lg-4>
                    <h3>Ceci est la future page "Librairie"</h3>
                </div>
            </div>
        </section>
</section>  <!-- section container-fluid-->